import numpy 
ar = numpy.array([1,2,3,4,5,6,41,7,8,9,10])
# ar is the ndarray object
print(ar)
ar1 = numpy.array( [
    [2,3],
    [4,5]
]    )
print(ar1)
